Run: python -m vid2kg.cli --url URL --out data/test
