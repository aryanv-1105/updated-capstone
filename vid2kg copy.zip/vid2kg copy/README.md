# vid2kg
See SETUP.md and QUICKSTART.md.
