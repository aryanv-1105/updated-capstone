from pathlib import Path
from typing import Optional
from yt_dlp import YoutubeDL

def fetch_audio(url: Optional[str], local: Optional[str], out_dir: Path) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    if local:
        p = Path(local)
        if not p.exists():
            raise FileNotFoundError(local)
        target = out_dir / p.name
        if target.resolve() != p.resolve():
            target.write_bytes(p.read_bytes())
        return target
    if not url:
        raise ValueError("Provide url or local file")
    ydl_opts = {
        "format": "bestaudio/best",
        "outtmpl": str(out_dir / "%(title).80s.%(id)s.%(ext)s"),
        "postprocessors": [{"key": "FFmpegExtractAudio", "preferredcodec": "m4a"}],
        "quiet": True,
        "noprogress": True,
    }
    with YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=True)
        filename = ydl.prepare_filename(info)
    p = Path(filename)
    if p.suffix.lower() != ".m4a":
        cand = p.with_suffix(".m4a")
        if cand.exists():
            p = cand
    return p
