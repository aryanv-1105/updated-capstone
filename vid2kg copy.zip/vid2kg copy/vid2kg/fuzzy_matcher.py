from rapidfuzz import fuzz, process
from typing import Dict
from rich import print as rprint

ERROR_CORRECTIONS = {'alu':'aloo','allu':'aloo','jeera':'cumin','dhaniya':'coriander','haldi':'turmeric','pyaz':'onion','mirch':'chilli','tamatar':'tomato','lehsun':'garlic','garam masla':'garam masala'}

class FuzzyMatcher:
    def __init__(self, threshold: float = 85.0):
        self.threshold = threshold

    def correct_transcript_text(self, text: str) -> Dict:
        corrected = text
        changes = []
        for wrong, right in ERROR_CORRECTIONS.items():
            if wrong in corrected.lower():
                corrected = corrected.replace(wrong, right).replace(wrong.title(), right)
                changes.append({'original': wrong, 'corrected': right})
        return {'corrected': corrected, 'corrections': changes, 'num_corrections': len(changes)}

def correct_transcript_segments(transcript: Dict, matcher: 'FuzzyMatcher') -> Dict:
    rprint("[cyan]Applying fuzzy matching corrections...[/cyan]")
    total = 0
    segs = []
    for s in transcript.get('segments', []):
        c = matcher.correct_transcript_text(s.get('text', ''))
        s2 = s.copy(); s2['text_before_correction'] = s.get('text', ''); s2['text'] = c['corrected']; s2['corrections'] = c['corrections']; s2['num_corrections'] = c['num_corrections']; segs.append(s2); total += c['num_corrections']
    transcript['segments'] = segs
    transcript['total_corrections'] = total
    return transcript
