from typing import Dict, Any, List, Optional
from rich import print as rprint

def normalize_recipe(recipe: Dict[str, Any]) -> Dict[str, Any]:
    # minimal pass-through normalizer
    for ing in recipe.get('ingredients', []):
        if ing.get('unit') == 'kg' and isinstance(ing.get('quantity'), (int,float)):
            ing['weight_grams'] = ing['quantity'] * 1000
    recipe['normalization_applied'] = True
    return recipe
