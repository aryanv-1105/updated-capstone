from pathlib import Path
from typing import Dict, Any

def transcribe(audio_path: Path, engine: str = "faster", model_size: str = "small", out_dir: Path = Path(".")) -> Dict[str, Any]:
    text = ""
    segments = []
    language = "und"
    try:
        if engine == "faster":
            from faster_whisper import WhisperModel
            model = WhisperModel(model_size)
            segs, info = model.transcribe(str(audio_path))
            language = info.language or "und"
            for i, seg in enumerate(segs):
                segments.append({"id": i, "start": seg.start, "end": seg.end, "text": seg.text})
                text += seg.text + "\n"
        else:
            import whisper
            model = whisper.load_model(model_size)
            result = model.transcribe(str(audio_path))
            language = result.get("language", "und")
            text = result.get("text", "")
            for i, s in enumerate(result.get("segments", [])):
                segments.append({"id": i, "start": s.get("start"), "end": s.get("end"), "text": s.get("text", "")})
    except Exception:
        pass
    return {"language": language, "text": text, "segments": segments}
